﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Complex
    {
        private int real;
        private int img;
        public int Real {
           get { return real; }
            set { real = value; }
        }
        public int Img
        {
            get { return img; }
            set { img = value; }
        }
        public Complex()
        {

        }
        public Complex(int r,int i)
        {
            this.real = r;
            this.img = i;
        }
        public static Complex operator+(Complex c1,Complex c2)
        {
            Complex temp = new Complex();
            temp.real = c1.real + c2.real;
            temp.img = c1.img + c2.img;
            return temp;

        }
        public static Complex operator-(Complex c1,Complex c2)
        {
            Complex temp = new Complex();
            temp.real = c1.real - c2.real;
            temp.img = c1.img - c2.img;
            return temp;
        }
        public static Complex operator *(Complex c1, Complex c2)
        {
            Complex temp = new Complex();
            temp.real = c1.real * c2.real;
            temp.img = c1.img * c2.img;
            return temp;
        }
        public static Complex operator/(Complex c1,Complex c2)
        {
            Complex temp = new Complex();
            temp.real = c1.real / c2.real;
            temp.img = c1.img / c2.img;
            return temp;
        }
    }
}
