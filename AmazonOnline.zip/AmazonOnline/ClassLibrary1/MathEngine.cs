﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    static public class MathEngine
    {
        public static int Addition(int n1,int n2)
        {
            return n1 + n2;
        }
        public static int Substraction(int n1, int n2)
        {
            return n1 - n2;
        }
        public static int Multiplication(int n1, int n2)
        {
            return n1 * n2;
        }
        public static int Division(int n1, int n2)
        {
            return n1 / n2;
        }
    }
}
