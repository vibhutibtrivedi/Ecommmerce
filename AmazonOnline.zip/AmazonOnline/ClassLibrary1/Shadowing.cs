﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathLib
{ 
        public class Parent
        {
            public virtual string Display()
            {
                return "this is parent details here";
            }
        }

        public class Child:Parent
        {
            public new  virtual   string Display()
            {
                return "this is child details here";
            }
        }


        public class GrandChild : Child
        {
            public override string Display()
            {
                return "this is child details here";
            }
        }


}
