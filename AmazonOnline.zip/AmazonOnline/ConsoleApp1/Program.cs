﻿using ClassLibrary1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MathLib;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //int num1 = 42;
            //int num2 = 43;

            //int result = MathEngine.Addition(num1, num2);
            //int result1= MathEngine.Substraction(num1, num2);
            //int result2 = MathEngine.Multiplication(num1, num2);
            //int result3 = MathEngine.Division(num1, num2);

            //Console.WriteLine("Result={0}", result);
            //Console.WriteLine("Result1={0}", result1);
            //Console.WriteLine("Result2={0}", result2);
            //Console.WriteLine("Result3={0}", result3);
            //Complex c1 = new Complex(42, 43);
            //Complex c2 = new Complex(12, 13);
            //Complex c3 = new Complex();
            //Complex c4 = new Complex();
            //Complex c5= new Complex();
            //Complex c6= new Complex();
            //c3 = c1 + c2;
            //c4 = c1 - c2;
            //c5 = c1 * c2;
            //c6 = c1 / c2;




            //OfficeBoy sweeper, waiter;
            //string s1; float f1;
            //sweeper = OfficeBoy.GetObject(); waiter = OfficeBoy.GetObject();
            //sweeper.Val = 60;
            //Console.WriteLine("Sweeper Value : {0}", sweeper.Val);
            //Console.WriteLine("Waiter Value : {0}", waiter.Val);
            //s1 = sweeper.Val.ToString();
            //f1 = (float)sweeper.Val;
            //sweeper.Val = int.Parse(s1);
            //sweeper.Val = Convert.ToInt32(s1);


         Child theChild = new Child();
            Parent thatParent = theChild;
            thatParent.Display();

            
            Console.ReadLine();

        }
    }
}
