﻿using ShoppingCart;
using CRM;
using System;
using System.Collections.Generic;

namespace OrderProcessing
{
    public class Order
    {
        public int OrderID { get; set; }
        public DateTime OrderDate { get; set; }
         
        public Order() { }
         
         
    }
}
