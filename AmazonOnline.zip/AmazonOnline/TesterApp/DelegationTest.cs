﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Banking;


namespace TesterApp
{
    class DelegationTest
    {
        public static void PayIncometax()
        {
            Console.WriteLine("15% Incometax will ne included");

        }
        public static void PayServicetax()
        {
            Console.WriteLine("10% Service tax will be included");
        }
        public static void PayVattax()
        {
            Console.WriteLine("5% Service tax will be included");
        }

        static void Main(string[]args)
        {
            AccountHandler operation1 = new AccountHandler(PayIncometax);
            AccountHandler operation2 = new AccountHandler(PayServicetax);
            AccountHandler operation3 = new AccountHandler(PayVattax);

            AccountHandler masteraccounthandler = null;
            masteraccounthandler += operation1;
            masteraccounthandler += operation2;
            masteraccounthandler += operation3;
            masteraccounthandler();
            Console.ReadLine();
        }
    }
}
