﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Banking;


namespace TesterApp


{

    public class Goverment
    {
        public static void PayIncomeTax()
        {
            Console.WriteLine("15%incometax is getting deducted from your account");
        }
    }
    public class IciciBank
    {
        public static void BlockAccount()
        {
            Console.WriteLine("your account has been Blocked");
        }
    }

    class DemoEventTest
    {
        static void Main(string[]args)
        {
            Account act1 = new Account(50000);
            act1.underbalance += new AccountHandler(IciciBank.BlockAccount);

            Account act2 = new Account(50000);
            act2.overbalance += new AccountHandler(Goverment.PayIncomeTax);

            Console.WriteLine("Initial Balance={0}", act1.Balance);
            Console.WriteLine("Enter amount to withdraw");
            float amount = float.Parse(Console.ReadLine());
            act1.Deposit(amount);
            Console.WriteLine("balance after operation");
            Console.WriteLine(act1.Balance);
            Console.ReadLine();


        }
    }
}
