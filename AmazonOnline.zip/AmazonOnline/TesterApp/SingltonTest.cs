﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShoppingCart;
using OrderProcessing;
using CRM;
using Catalog;

namespace TesterApp
{
    class SingltonTest
    {
        static void Main(string[]args)
        {
            PurchaseManager mgr1, mgr2,mgr3;

            mgr1 = PurchaseManager.GetManager();
            mgr2 = PurchaseManager.GetManager();
            mgr3 = PurchaseManager.GetManager();

            Product product1 = new Product(1, "Rose", "Valentine flower", 10, 400);
            Product product2 = new Product(2, "Marigold", "Festival flower", 5, 500);

            Item item1 = new Item(product1, 34);
            Item item2 = new Item(product2, 56);

            Cart cart1 = new Cart();

            cart1.AddToCart(item1);
            cart1.AddToCart(item2);

            List<Item> cartItems = cart1.Items;
            DateTime ordDate = DateTime.Now;
            Customer customer1 = new Customer
            {
                UserID = "100",
                FullName = "Vibhuti Joshi",
                Email = "vibhuti28@gmail.com",
                ContactNubmer = "9427540899",
                Location = "Pune",
                Password = "123#"
            };
            Order theOrder = new PurchaseOrder(1001, ordDate, customer1, cartItems);

            mgr1.Orders = new List<Order>();
            mgr1.Orders.Add(theOrder);
            //int Count=mgr2.Orders.Count;
          
            foreach(PurchaseOrder order in mgr3.Orders)
            {
                Console.WriteLine(order.theCustomer.FullName);
                Console.WriteLine(order.theCustomer.Email);
                Console.WriteLine(order.OrderID);
                Console.WriteLine(order.OrderDate);
                Console.WriteLine("Item Details");

                foreach(Item item in order.Items)
                {
                    Console.WriteLine(item.theProduct + "Quantity=" + item.Quantity);
                }
            }
            Console.ReadLine();


        }
    }
}
